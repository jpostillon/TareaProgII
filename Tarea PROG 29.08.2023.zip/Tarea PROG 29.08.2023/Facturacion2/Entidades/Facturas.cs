﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facturacion2.Entidades
{
    internal class Facturas
    {
        public int NroFactura { get; set; }
        public DateTime Fecha { get; set; }
        public FormaPago FormaPago { get; set; }

        public string Cliente { get; set; }

        public List<DetalleProducto> ListaFactura { get; set; }

        public Facturas()
        {
            ListaFactura = new List<DetalleProducto>();
        }

        public void AgregarLista(DetalleProducto detalle)
        {
            ListaFactura.Add(detalle);
        }

        public void QuitarLista(int posicion)
        {
            ListaFactura.RemoveAt(posicion);
        }

        public double CalcularTotal()
        {
            double total = 0;

            foreach (DetalleProducto i in ListaFactura)
            {
                total += i.calcularsubtotal();
            }
            return total;
        }


    }
}
