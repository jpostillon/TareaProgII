

Create database Facturacion2
go
use Facturacion2
go

create table FORMAPAGO(
id_formapago int identity (1,1) not null ,
nombre varchar (80) null,
constraint PK_FORMAPAGO primary key (id_formapago));


create table ARTICULOS (
id_articulo int identity (1,1)not null,
nombre varchar (80) null,
precio_unitario numeric (8,2) NOT NULL,
constraint PK_ARTICULOS primary key (id_articulo));

create table FACTURAS (
factura_nro int identity (1,1) not null,
fecha date  not null,
formapago int  not null,
cliente varchar (80)  null,
descuento int null ,
total numeric (8,2) not null
constraint PK_FACTURAS primary key (factura_nro),
constraint FK_FACTURAS_FORMAPAGO foreign key (formapago)
references FORMAPAGO (id_formapago));

create table DETALLES_FACTURAS(
factura_nro int not null,
detalle_nro int not null,
articulo_nro int  not null,
cantidad int ,
constraint PK_DETALLES_FACTURAS primary key (detalle_nro),
constraint FK_DETALLES_FACTURAS_ARTICULOS foreign key (articulo_nro)
references ARTICULOS (id_articulo),
constraint FK_DETALLES_FACTURAS_FACTURAS foreign key (factura_nro)
references FACTURAS (factura_nro));

insert into FORMAPAGO values ('EFECTIVO');
insert into FORMAPAGO values ('TARJETA DE DEBITO');
insert into FORMAPAGO values ('TARJETA DE CREDITO');
insert into FORMAPAGO values ('CHEQUES');

INSERT INTO ARTICULOS VALUES ('ZAPATILLA',15000);
INSERT INTO ARTICULOS VALUES ('REMERA',20000);
INSERT INTO ARTICULOS VALUES ('PANTALON ',35000);
INSERT INTO ARTICULOS VALUES ('SOGA',285000);
INSERT INTO ARTICULOS VALUES ('PELOTA',15000);
INSERT INTO ARTICULOS VALUES ('GUANTES',4500);
INSERT INTO ARTICULOS VALUES ('RAQUETA',12400);
INSERT INTO ARTICULOS VALUES ('PALETA',100);
INSERT INTO ARTICULOS VALUES ('BUZO',15000);
INSERT INTO ARTICULOS VALUES ('CAMPERA',18000);

insert into FACTURAS (fecha,formapago,total) values ('12/08/2023',1,321.32);


CREATE PROCEDURE SP_CONSULTAR_ARTICULO
AS
BEGIN
		select * from ARTICULOS
END;




create procedure SP_INSERTAR_DETALLES

@factura_nro int,
@detalle_nro int,
@cantidad int
as
begin

insert into DETALLES_FACTURAS(factura_nro,detalle_nro,cantidad)
VALUES (@factura_nro,@detalle_nro,@cantidad)
end;


create procedure SP_INSERTAR_FACTURAS
@cliente varchar (80),
@descuento int ,
@total numeric (8,2),
@nrofactura int output
as
begin

INSERT INTO FACTURAS (fecha,cliente,descuento,total)
VALUES (getdate(),@cliente,@descuento,@total);

end;



CREATE PROCEDURE SP_PROXIMO_ID
@next int OUTPUT
AS
BEGIN
	SET @next = (SELECT MAX(factura_nro)+1  FROM FACTURAS);
END;


create procedure SP_CONSULTAR_FORMAPAGO
AS
BEGIN
SELECT * FROM FORMAPAGO
END;